$(function() {
    setTimeout(function () {
        $('.fly-in-text').removeClass('hidden');
    }, 500);
})();



$( document ).ready(function(){
    $('#Welkom').fadeIn('slow', function(){
        $('#Welkom').delay(5000).fadeOut();
    });
});



$(document).ready(function() {
    $(".menu-icon").on("click", function() {
        $("nav ul").toggleClass("showing");
    });
});


$(window).on("scroll", function() {
    if($(window).scrollTop()) {
        $('nav').addClass('black');
    }

    else {
        $('nav').removeClass('black');
    }
});

// Menu-toggle button

$(document).ready(function() {
    $(".menu-icon").on("click", function() {
        $("nav ul").toggleClass("showing");
    });
});

// Scrolling Effect

$(window).on("scroll", function() {
    if($(window).scrollTop()) {
        $('nav').addClass('black');
    }

    else {
        $('nav').removeClass('black');
    }
});




//
   // $(function(){
   //     var navbar = $('.navbar');
   //
   //     $(window).scroll(function(){
   //         if($(window).scrollTop() <= 40){
   //             navbar.removeClass('navbar-scroll');
   //         } else {
   //             navbar.addClass('navbar-scroll');
   //         }
   //     });
   // });
   //
